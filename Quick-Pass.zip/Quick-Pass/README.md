# Quick-Pass

After Covid19 lockdown you may plan to invite general public for any event, exhibition, your restaurant or clinic or any other business you run but you will have to restrict the number of people coming every hour or for every event keeping in mind the social distancing norms.

Automate it all with QuickPass!

Send a link to your guests asking them to register themselves for the event or to visit you. They do it on their mobile phones and generate their own passes in seconds. They then come with the screenshot or a print of the pass to your event. No more turning away of people who come to you and you regulate their entry!
